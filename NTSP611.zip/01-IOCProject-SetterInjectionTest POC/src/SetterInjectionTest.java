
public class SetterInjectionTest {

}
