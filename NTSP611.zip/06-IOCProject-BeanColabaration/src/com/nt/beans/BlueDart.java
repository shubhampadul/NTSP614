package com.nt.beans;

import com.nt.test.Courier;

public class BlueDart implements Courier {

	@Override
	public String deliver(int oid) {
		
		return null;
	}

}
