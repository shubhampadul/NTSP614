package com.nt.beans;

import com.nt.test.Courier;

public class DTDC implements Courier {
	
	@Override
	public String deliver(int oid) {
		
		
		return "";
	}
}
