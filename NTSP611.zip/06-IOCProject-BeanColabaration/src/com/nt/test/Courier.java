package com.nt.test;

public interface Courier{
	public String deliver(int oid);
}