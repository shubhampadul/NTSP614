package com.nt.engine;

public interface Engine {
	
	public void start();
	public void stop();
}
