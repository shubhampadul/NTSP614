package com.nt.engine;

public class DiselEngine implements Engine{
	@Override
	public void start() {
		System.out.println("DiselEngine.start()");
		
	}
	@Override
	public void stop() {
		System.out.println("DiselEngine.stop()");
		
	}

}
