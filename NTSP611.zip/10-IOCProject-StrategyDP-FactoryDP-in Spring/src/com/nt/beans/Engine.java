package com.nt.beans;

public interface Engine {
	
	public void start();
	public void stop();
}
