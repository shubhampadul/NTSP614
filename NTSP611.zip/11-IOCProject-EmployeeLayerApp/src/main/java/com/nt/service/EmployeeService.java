package com.nt.service;

import com.nt.dto.EmployeeDTO;

public interface EmployeeService {
	
	public String registerEmployee(EmployeeDTO dto)throws Exception;

}
