package com.nt.vo;

public class EmployeeVO {
	
	String empNo;
	String empName;
	String empAdrs;
	String basicSal;
	
	
	
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAdrs() {
		return empAdrs;
	}
	public void setEmpAdrs(String empAdrs) {
		this.empAdrs = empAdrs;
	}
	public String getBasicSal() {
		return basicSal;
	}
	public void setBasicSal(String basicSal) {
		this.basicSal = basicSal;
	}
	
	

}
