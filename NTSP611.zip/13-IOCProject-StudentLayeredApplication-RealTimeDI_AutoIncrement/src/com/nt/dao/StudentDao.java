package com.nt.dao;

import com.nt.bo.StudentBo;

public interface StudentDao {
	public int insert(StudentBo bo)throws Exception;

}
