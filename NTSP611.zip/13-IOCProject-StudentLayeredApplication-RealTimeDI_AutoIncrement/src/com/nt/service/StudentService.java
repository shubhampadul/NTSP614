package com.nt.service;

import com.nt.dto.StudentDto;

public interface StudentService {
	public String generateResult(StudentDto dto)throws Exception;

}
