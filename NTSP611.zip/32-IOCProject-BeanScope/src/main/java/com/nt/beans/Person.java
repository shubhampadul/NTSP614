package com.nt.beans;

public class Person {
	    
	    public Person() {
	    	System.out.println("Person.Person()");
	    }
	
		public void eating() {
			System.out.println("Person.eating()");
		}
		public void sleeping() {
			System.out.println("Person.sleeping()");
		}
		
		
}
