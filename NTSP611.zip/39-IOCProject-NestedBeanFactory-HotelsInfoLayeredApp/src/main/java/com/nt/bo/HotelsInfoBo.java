package com.nt.bo;

import lombok.Data;

@Data
public class HotelsInfoBo {
	private long regNo;
	private String hname;
	private String type;
	private String addrs;
	private String loc;
	private String checkIn;
	private String checkOut;

}
