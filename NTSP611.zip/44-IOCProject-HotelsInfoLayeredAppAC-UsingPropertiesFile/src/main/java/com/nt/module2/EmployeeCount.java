package com.nt.module2;

import java.io.FileInputStream;
import java.io.InputStream;

import com.sun.xml.internal.stream.buffer.sax.Properties;

public class EmployeeCount {

	public static void main(String[] args) {
		Properties props=null;
		InputStream is=null;
		//is=new FileInputStream("com/nt/commons/jdbc1.properties");
	//	props=new Properties(is);
		
		//Class.forName()

	}

}
