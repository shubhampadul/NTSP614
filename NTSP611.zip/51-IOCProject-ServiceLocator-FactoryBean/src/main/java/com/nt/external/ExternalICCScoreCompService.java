package com.nt.external;

public interface ExternalICCScoreCompService {
	public String getScore(int mid)throws IllegalArgumentException;

}
