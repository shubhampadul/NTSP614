
package com.nt.service;

public interface CrickBuzzScoreService {
	public String findScore(int mid);
}