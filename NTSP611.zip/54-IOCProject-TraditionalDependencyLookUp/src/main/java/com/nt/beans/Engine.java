package com.nt.beans;

public class Engine {
	public Engine() {
		System.out.println("Engine.Engine()");
	}	
	public void start() {
		System.out.println("engine started");
	}
	public void end() {
		System.out.println("engine stopped");
	}
}